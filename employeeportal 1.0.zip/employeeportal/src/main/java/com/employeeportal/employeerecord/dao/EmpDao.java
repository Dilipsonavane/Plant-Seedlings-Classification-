package com.employeeportal.employeerecord.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeeportal.employeerecord.entities.Employees;

@Repository
public interface EmpDao extends JpaRepository<Employees, Long> {
	

}

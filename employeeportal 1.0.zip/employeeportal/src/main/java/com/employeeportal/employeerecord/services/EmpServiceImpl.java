package com.employeeportal.employeerecord.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeportal.employeerecord.dao.EmpDao;
import com.employeeportal.employeerecord.entities.Employees;

@Service
public class EmpServiceImpl implements EmpService {
	
	@Autowired
	private EmpDao empDao;
	
//	List<Employees> list;
	
	public EmpServiceImpl() {
/*		list = new ArrayList<>();
		list.add( new Employees (111,"Kevin","Mumbai","Development"));
		list.add( new Employees (222,"John","Delhi","Testing"));
*/
	}

	@Override
	public List<Employees> getEmployees() {
		return empDao.findAll();
	}

	@Override
	public Employees getEmployee(long empID) {
		
/*		Employees e=null;
		for(Employees emp:list)
		{
			if(emp.getId()==empID)
			{
				e=emp;
				break;
			}
		}*/
		return empDao.findById(empID).get();
	}

	@Override
	public Employees addEmployee(Employees emp) {
//		list.add(emp);
		
		empDao.save(emp);
		return emp;
	}

	@Override
	public Employees updateEmployee(Employees emp) {
/*		list.forEach(e ->{
			if(e.getId()==emp.getId()) {
				e.setName(emp.getName());
				e.setAddress(emp.getAddress());
				e.setDept(emp.getDept());
			}
		});
*/
		empDao.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(long parseLong) {
//		list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
		Employees entity=empDao.getOne(parseLong);
		empDao.delete(entity);
	}

}

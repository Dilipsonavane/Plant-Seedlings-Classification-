package com.employeeportal.employeerecord.services;

import java.util.List;

import com.employeeportal.employeerecord.entities.Employees;


public interface EmpService {
	
	public List<Employees> getEmployees();
	
	public Employees getEmployee(long empID);
	
	public Employees addEmployee(Employees emp);
	
	public Employees updateEmployee(Employees emp);
	
	public void deleteEmployee(long parseLong);
}
